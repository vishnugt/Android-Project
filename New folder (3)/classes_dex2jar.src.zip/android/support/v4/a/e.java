package android.support.v4.a;

import android.content.Intent;
import java.util.ArrayList;

final class e
{
  final Intent a;
  final ArrayList<f> b;
  
  e(Intent paramIntent, ArrayList<f> paramArrayList)
  {
    this.a = paramIntent;
    this.b = paramArrayList;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.e
 * JD-Core Version:    0.7.0.1
 */