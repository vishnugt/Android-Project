package android.support.v4.a;

public abstract interface b<D>
{
  public abstract void a(a<D> parama, D paramD);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.b
 * JD-Core Version:    0.7.0.1
 */