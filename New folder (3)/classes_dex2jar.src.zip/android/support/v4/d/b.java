package android.support.v4.d;

import android.graphics.Canvas;

final class b
  implements d
{
  public final void a(Object paramObject, int paramInt1, int paramInt2) {}
  
  public final boolean a(Object paramObject)
  {
    return true;
  }
  
  public final boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }
  
  public final boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }
  
  public final void b(Object paramObject) {}
  
  public final boolean c(Object paramObject)
  {
    return false;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.d.b
 * JD-Core Version:    0.7.0.1
 */