package android.support.v4.d;

import android.graphics.Canvas;

abstract interface d
{
  public abstract void a(Object paramObject, int paramInt1, int paramInt2);
  
  public abstract boolean a(Object paramObject);
  
  public abstract boolean a(Object paramObject, float paramFloat);
  
  public abstract boolean a(Object paramObject, Canvas paramCanvas);
  
  public abstract void b(Object paramObject);
  
  public abstract boolean c(Object paramObject);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.d.d
 * JD-Core Version:    0.7.0.1
 */