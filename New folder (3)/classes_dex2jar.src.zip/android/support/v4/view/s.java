package android.support.v4.view;

import android.view.View;

final class s
  extends r
{
  public final void b(View paramView)
  {
    paramView.postInvalidateOnAnimation();
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.s
 * JD-Core Version:    0.7.0.1
 */