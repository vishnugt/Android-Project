package android.support.v4.view;

import android.database.DataSetObserver;

final class ab
  extends DataSetObserver
{
  private ab(ViewPager paramViewPager) {}
  
  public final void onChanged()
  {
    this.a.a();
  }
  
  public final void onInvalidated()
  {
    this.a.a();
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.7.0.1
 */