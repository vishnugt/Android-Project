package android.support.v4.view;

abstract interface d
{
  public abstract boolean a(int paramInt);
  
  public abstract boolean b(int paramInt);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.d
 * JD-Core Version:    0.7.0.1
 */