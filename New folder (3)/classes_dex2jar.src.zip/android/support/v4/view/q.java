package android.support.v4.view;

import android.animation.ValueAnimator;

class q
  extends p
{
  final long a()
  {
    return ValueAnimator.getFrameDelay();
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.q
 * JD-Core Version:    0.7.0.1
 */