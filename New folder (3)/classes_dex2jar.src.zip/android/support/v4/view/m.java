package android.support.v4.view;

import android.view.VelocityTracker;

abstract interface m
{
  public abstract float a(VelocityTracker paramVelocityTracker, int paramInt);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.m
 * JD-Core Version:    0.7.0.1
 */