package android.support.v4.view;

final class x
{
  Object a;
  int b;
  boolean c;
  float d;
  float e;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.x
 * JD-Core Version:    0.7.0.1
 */