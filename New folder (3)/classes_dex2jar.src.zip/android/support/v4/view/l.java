package android.support.v4.view;

import android.view.VelocityTracker;

final class l
  implements m
{
  public final float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return paramVelocityTracker.getXVelocity(paramInt);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.l
 * JD-Core Version:    0.7.0.1
 */