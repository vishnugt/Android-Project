package android.support.v4.view;

import android.support.v4.b.c;

final class ac
  implements c<ViewPager.SavedState>
{}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ac
 * JD-Core Version:    0.7.0.1
 */