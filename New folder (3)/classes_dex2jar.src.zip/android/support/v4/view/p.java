package android.support.v4.view;

import android.view.View;

class p
  extends o
{
  public final int a(View paramView)
  {
    return paramView.getOverScrollMode();
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.p
 * JD-Core Version:    0.7.0.1
 */