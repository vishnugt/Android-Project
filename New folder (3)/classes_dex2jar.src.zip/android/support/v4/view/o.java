package android.support.v4.view;

import android.view.View;

class o
  implements t
{
  public int a(View paramView)
  {
    return 2;
  }
  
  long a()
  {
    return 10L;
  }
  
  public boolean a(View paramView, int paramInt)
  {
    return false;
  }
  
  public void b(View paramView)
  {
    paramView.postInvalidateDelayed(a());
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.7.0.1
 */