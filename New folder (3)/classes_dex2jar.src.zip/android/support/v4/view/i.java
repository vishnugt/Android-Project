package android.support.v4.view;

import android.database.DataSetObservable;

public abstract class i
{
  DataSetObservable a;
  
  public static void b()
  {
    throw new UnsupportedOperationException("Required method destroyItem was not overridden");
  }
  
  public abstract int a();
  
  public abstract boolean c();
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.i
 * JD-Core Version:    0.7.0.1
 */