package android.support.v4.app;

import android.os.Parcelable.Creator;

final class m
  implements Parcelable.Creator<FragmentManagerState>
{}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.7.0.1
 */