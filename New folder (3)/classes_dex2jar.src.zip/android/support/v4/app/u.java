package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class u
  extends AndroidRuntimeException
{
  public u(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.u
 * JD-Core Version:    0.7.0.1
 */