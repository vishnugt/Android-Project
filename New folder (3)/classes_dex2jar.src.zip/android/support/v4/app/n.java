package android.support.v4.app;

import android.os.Parcelable.Creator;

final class n
  implements Parcelable.Creator<FragmentState>
{}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.n
 * JD-Core Version:    0.7.0.1
 */