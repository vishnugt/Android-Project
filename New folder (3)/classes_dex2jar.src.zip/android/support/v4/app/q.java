package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.a;

public abstract interface q<D>
{
  public abstract a<D> onCreateLoader(int paramInt, Bundle paramBundle);
  
  public abstract void onLoadFinished(a<D> parama, D paramD);
  
  public abstract void onLoaderReset(a<D> parama);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.q
 * JD-Core Version:    0.7.0.1
 */