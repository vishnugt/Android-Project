package android.support.v4.app;

import android.support.v4.a.a;

public abstract class p
{
  public abstract <D> a<D> a(q<D> paramq);
  
  public boolean a()
  {
    return false;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.p
 * JD-Core Version:    0.7.0.1
 */