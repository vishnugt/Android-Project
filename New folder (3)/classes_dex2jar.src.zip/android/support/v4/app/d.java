package android.support.v4.app;

public final class d
  extends RuntimeException
{
  public d(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.d
 * JD-Core Version:    0.7.0.1
 */