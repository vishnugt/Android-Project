package android.support.v4.app;

import android.os.Parcelable.Creator;

final class c
  implements Parcelable.Creator<BackStackState>
{}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.c
 * JD-Core Version:    0.7.0.1
 */