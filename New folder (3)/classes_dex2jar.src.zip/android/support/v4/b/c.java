package android.support.v4.b;

import android.os.Parcel;

public abstract interface c<T>
{
  public abstract T a(Parcel paramParcel, ClassLoader paramClassLoader);
  
  public abstract T[] a(int paramInt);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.c
 * JD-Core Version:    0.7.0.1
 */