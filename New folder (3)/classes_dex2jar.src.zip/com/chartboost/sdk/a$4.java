package com.chartboost.sdk;

import com.chartboost.sdk.impl.a.c;
import com.chartboost.sdk.impl.j.b;
import com.chartboost.sdk.impl.k;
import org.json.JSONObject;

class a$4
  implements j.b
{
  a$4(a parama, boolean paramBoolean1, boolean paramBoolean2) {}
  
  public void a(k paramk, String paramString)
  {
    a.a(this.a, a.c.c, null);
    b localb = a.b(this.a).a();
    if ((localb != null) && (localb.a())) {
      localb.a(true);
    }
  }
  
  public void a(JSONObject paramJSONObject, k paramk)
  {
    a.a(this.a, paramJSONObject, a.c.c, this.b, null, this.c);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.a.4
 * JD-Core Version:    0.7.0.1
 */