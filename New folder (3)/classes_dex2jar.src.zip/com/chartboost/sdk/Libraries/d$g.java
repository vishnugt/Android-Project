package com.chartboost.sdk.Libraries;

public class d$g
{
  private String a;
  private d.a b;
  
  public d$g(String paramString, d.a parama)
  {
    this.a = paramString;
    this.b = parama;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Libraries.d.g
 * JD-Core Version:    0.7.0.1
 */