package com.chartboost.sdk.Libraries;

import org.json.JSONObject;

class d$h
  extends d.a
{
  public String a()
  {
    return "object must be null.";
  }
  
  public boolean a(Object paramObject)
  {
    return (paramObject == null) || (paramObject == JSONObject.NULL);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Libraries.d.h
 * JD-Core Version:    0.7.0.1
 */