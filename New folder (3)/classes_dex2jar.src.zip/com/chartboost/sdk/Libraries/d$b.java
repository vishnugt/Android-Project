package com.chartboost.sdk.Libraries;

class d$b
  extends d.a
{
  public String a()
  {
    return "object must be a boolean.";
  }
  
  public boolean a(Object paramObject)
  {
    return (Boolean.class.isInstance(paramObject)) || (Boolean.TYPE.isInstance(paramObject));
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Libraries.d.b
 * JD-Core Version:    0.7.0.1
 */