package com.chartboost.sdk.Libraries;

class d$j
  extends d.e
{
  public d$j()
  {
    super(String.class);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Libraries.d.j
 * JD-Core Version:    0.7.0.1
 */