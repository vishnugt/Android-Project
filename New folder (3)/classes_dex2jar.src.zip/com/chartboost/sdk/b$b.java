package com.chartboost.sdk;

import com.chartboost.sdk.impl.a;
import com.chartboost.sdk.impl.a.b;

class b$b
  implements Runnable
{
  private a b;
  private boolean c;
  
  public b$b(b paramb, a parama, boolean paramBoolean)
  {
    this.b = parama;
    this.c = paramBoolean;
  }
  
  public void run()
  {
    if (this.b.c == a.b.d)
    {
      this.b.c = a.b.a;
      this.a.b(this.b, this.c);
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.b.b
 * JD-Core Version:    0.7.0.1
 */