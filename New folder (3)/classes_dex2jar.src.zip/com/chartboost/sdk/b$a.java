package com.chartboost.sdk;

import com.chartboost.sdk.impl.a;

public final class b$a
{
  protected boolean a;
  protected a b;
  
  public b$a(a parama)
  {
    this.a = false;
    this.b = parama;
  }
  
  protected b$a(boolean paramBoolean, a parama)
  {
    this.a = paramBoolean;
    this.b = parama;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.b.a
 * JD-Core Version:    0.7.0.1
 */