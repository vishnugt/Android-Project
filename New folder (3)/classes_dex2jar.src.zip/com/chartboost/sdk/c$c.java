package com.chartboost.sdk;

import org.json.JSONObject;

public abstract interface c$c
{
  public abstract void a(String paramString, JSONObject paramJSONObject);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.c.c
 * JD-Core Version:    0.7.0.1
 */