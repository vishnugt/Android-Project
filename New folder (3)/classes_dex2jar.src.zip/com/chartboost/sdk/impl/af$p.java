package com.chartboost.sdk.impl;

class af$p
  extends ac
{
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    ae.a(paramStringBuilder, (String)paramObject);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.p
 * JD-Core Version:    0.7.0.1
 */