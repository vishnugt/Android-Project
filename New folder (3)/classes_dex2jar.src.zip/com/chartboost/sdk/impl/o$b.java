package com.chartboost.sdk.impl;

import android.os.Bundle;
import com.chartboost.sdk.Libraries.a.a;

public abstract interface o$b
{
  public abstract void a(a.a parama, Bundle paramBundle);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.o.b
 * JD-Core Version:    0.7.0.1
 */