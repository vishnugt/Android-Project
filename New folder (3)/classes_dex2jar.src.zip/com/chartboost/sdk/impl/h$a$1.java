package com.chartboost.sdk.impl;

import android.view.View;
import android.view.View.OnClickListener;
import com.chartboost.sdk.c.a;

class h$a$1
  implements View.OnClickListener
{
  h$a$1(h.a parama) {}
  
  public void onClick(View paramView)
  {
    if (h.a.b(this.a).a != null) {
      h.a.b(this.a).a.a();
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.h.a.1
 * JD-Core Version:    0.7.0.1
 */