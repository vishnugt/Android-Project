package com.chartboost.sdk.impl;

public abstract interface n$a
{
  public abstract void a(boolean paramBoolean, String paramString);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.n.a
 * JD-Core Version:    0.7.0.1
 */