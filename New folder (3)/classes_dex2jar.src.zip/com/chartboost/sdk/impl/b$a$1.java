package com.chartboost.sdk.impl;

import android.view.View;
import android.view.View.OnClickListener;
import com.chartboost.sdk.c.a;

class b$a$1
  implements View.OnClickListener
{
  b$a$1(b.a parama) {}
  
  public void onClick(View paramView)
  {
    if (b.a.a(this.a).a != null) {
      b.a.a(this.a).a.a();
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.b.a.1
 * JD-Core Version:    0.7.0.1
 */