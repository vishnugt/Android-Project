package com.chartboost.sdk.impl;

class af$q
  extends ac
{
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    paramStringBuilder.append(paramObject.toString());
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.q
 * JD-Core Version:    0.7.0.1
 */