package com.chartboost.sdk.impl;

import android.os.Bundle;
import com.chartboost.sdk.Libraries.a.a;

class b$3
  implements o.b
{
  b$3(b paramb) {}
  
  public void a(a.a parama, Bundle paramBundle)
  {
    this.a.k = parama;
    b.a(this.a, parama);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.b.3
 * JD-Core Version:    0.7.0.1
 */