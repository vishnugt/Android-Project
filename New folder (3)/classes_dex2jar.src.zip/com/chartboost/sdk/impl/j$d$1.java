package com.chartboost.sdk.impl;

class j$d$1
  implements Runnable
{
  j$d$1(j.d paramd, boolean paramBoolean, String paramString) {}
  
  public void run()
  {
    j.a locala = j.d.a(this.a);
    if ((this.b) && (j.a.c(locala) != null))
    {
      if (j.a.d(locala) != null) {
        j.a.d(locala).a(j.a.c(locala), j.a.a(locala));
      }
      return;
    }
    locala.a(this.c);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.j.d.1
 * JD-Core Version:    0.7.0.1
 */