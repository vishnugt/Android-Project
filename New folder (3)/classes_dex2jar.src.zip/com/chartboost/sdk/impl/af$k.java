package com.chartboost.sdk.impl;

class af$k
  extends af.c
{
  af$k(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    this.a.a(new y("$maxKey", Integer.valueOf(1)), paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.k
 * JD-Core Version:    0.7.0.1
 */