package com.chartboost.sdk.impl;

class af$l
  extends af.c
{
  af$l(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    this.a.a(new y("$minKey", Integer.valueOf(1)), paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.l
 * JD-Core Version:    0.7.0.1
 */