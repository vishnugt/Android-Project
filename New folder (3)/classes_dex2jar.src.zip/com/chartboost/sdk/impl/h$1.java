package com.chartboost.sdk.impl;

import android.os.Bundle;
import android.util.SparseArray;
import com.chartboost.sdk.Libraries.a.a;

class h$1
  implements o.b
{
  h$1(h paramh) {}
  
  public void a(a.a parama, Bundle paramBundle)
  {
    h.e(this.a).put(paramBundle.getInt("index"), parama);
    h.a(this.a, parama);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.h.1
 * JD-Core Version:    0.7.0.1
 */