package com.chartboost.sdk.impl;

import com.chartboost.sdk.c.a;

class a$2
  implements c.a
{
  a$2(a parama1, a parama2) {}
  
  public void a()
  {
    if (this.b.g != null) {
      this.b.g.b(this.b);
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.a.2
 * JD-Core Version:    0.7.0.1
 */