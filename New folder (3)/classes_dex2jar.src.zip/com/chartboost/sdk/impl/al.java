package com.chartboost.sdk.impl;

import java.util.Set;

public abstract interface al
{
  public abstract Object a(String paramString);
  
  public abstract Object a(String paramString, Object paramObject);
  
  public abstract boolean b(String paramString);
  
  public abstract Set<String> keySet();
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.al
 * JD-Core Version:    0.7.0.1
 */