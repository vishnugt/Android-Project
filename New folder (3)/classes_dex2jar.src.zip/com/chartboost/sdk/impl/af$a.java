package com.chartboost.sdk.impl;

class af$a
  extends af.c
{
  af$a(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    aw localaw = (aw)paramObject;
    y localy = new y();
    localy.a("$code", localaw.a());
    this.a.a(localy, paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.a
 * JD-Core Version:    0.7.0.1
 */