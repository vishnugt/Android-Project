package com.chartboost.sdk.impl;

public abstract interface p$a
{
  public abstract void a(a parama);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.p.a
 * JD-Core Version:    0.7.0.1
 */