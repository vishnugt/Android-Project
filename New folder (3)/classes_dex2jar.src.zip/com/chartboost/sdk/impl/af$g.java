package com.chartboost.sdk.impl;

class af$g
  extends af.c
{
  af$g(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    au localau = (au)paramObject;
    y localy = new y();
    localy.a("$ts", Integer.valueOf(localau.a()));
    localy.a("$inc", Integer.valueOf(localau.b()));
    this.a.a(localy, paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.g
 * JD-Core Version:    0.7.0.1
 */