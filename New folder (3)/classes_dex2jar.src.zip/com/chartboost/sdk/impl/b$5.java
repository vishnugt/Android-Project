package com.chartboost.sdk.impl;

import android.os.Bundle;
import com.chartboost.sdk.Libraries.a.a;

class b$5
  implements o.b
{
  b$5(b paramb) {}
  
  public void a(a.a parama, Bundle paramBundle)
  {
    this.a.l = parama;
    b.a(this.a, parama);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.b.5
 * JD-Core Version:    0.7.0.1
 */