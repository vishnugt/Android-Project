package com.chartboost.sdk.impl;

class af$n
  extends af.c
{
  af$n(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    this.a.a(new y("$oid", paramObject.toString()), paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.n
 * JD-Core Version:    0.7.0.1
 */