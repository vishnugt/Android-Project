package com.chartboost.sdk.impl;

import android.app.Activity;

class n$1$1
  implements Runnable
{
  n$1$1(n.1 param1, String paramString, Activity paramActivity) {}
  
  public void run()
  {
    n.a(n.1.a(this.a), this.b, this.c);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.n.1.1
 * JD-Core Version:    0.7.0.1
 */