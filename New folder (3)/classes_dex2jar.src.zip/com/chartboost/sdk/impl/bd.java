package com.chartboost.sdk.impl;

public class bd
{
  public static <T> T a(String paramString, T paramT)
  {
    if (paramT == null) {
      throw new bd.a(paramString);
    }
    return paramT;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.bd
 * JD-Core Version:    0.7.0.1
 */