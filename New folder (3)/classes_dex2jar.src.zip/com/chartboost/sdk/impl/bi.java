package com.chartboost.sdk.impl;

abstract interface bi<A, B>
{
  public abstract B a(A paramA);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.bi
 * JD-Core Version:    0.7.0.1
 */