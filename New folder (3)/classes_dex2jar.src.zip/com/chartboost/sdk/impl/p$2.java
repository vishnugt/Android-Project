package com.chartboost.sdk.impl;

class p$2
  implements Runnable
{
  p$2(p.a parama, a parama1) {}
  
  public void run()
  {
    if (this.a != null) {
      this.a.a(this.b);
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.p.2
 * JD-Core Version:    0.7.0.1
 */