package com.chartboost.sdk.impl;

class bd$a
  extends IllegalArgumentException
{
  bd$a(String paramString)
  {
    super(paramString + " should not be null!");
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.bd.a
 * JD-Core Version:    0.7.0.1
 */