package com.chartboost.sdk.impl;

class af$e
  extends af.c
{
  af$e(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    ab localab = (ab)paramObject;
    y localy = new y();
    localy.a("$ref", localab.b());
    localy.a("$id", localab.a());
    this.a.a(localy, paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.e
 * JD-Core Version:    0.7.0.1
 */