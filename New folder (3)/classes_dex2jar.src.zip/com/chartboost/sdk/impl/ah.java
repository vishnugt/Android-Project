package com.chartboost.sdk.impl;

public abstract interface ah
{
  public abstract void a(Object paramObject, StringBuilder paramStringBuilder);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.ah
 * JD-Core Version:    0.7.0.1
 */