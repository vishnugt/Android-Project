package com.chartboost.sdk.impl;

import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

public class af
{
  public static ah a()
  {
    ad localad = b();
    localad.a(Date.class, new af.i(localad));
    localad.a(au.class, new af.g(localad));
    localad.a(av.class, new af.h(null));
    localad.a([B.class, new af.h(null));
    return localad;
  }
  
  static ad b()
  {
    ad localad = new ad();
    localad.a([Ljava.lang.Object.class, new af.m(localad));
    localad.a(Boolean.class, new af.q(null));
    localad.a(aw.class, new af.a(localad));
    localad.a(ax.class, new af.b(localad));
    localad.a(aa.class, new af.d(localad));
    localad.a(ab.class, new af.e(localad));
    localad.a(Iterable.class, new af.f(localad));
    localad.a(Map.class, new af.j(localad));
    localad.a(ay.class, new af.k(localad));
    localad.a(az.class, new af.l(localad));
    localad.a(Number.class, new af.q(null));
    localad.a(ba.class, new af.n(localad));
    localad.a(Pattern.class, new af.o(localad));
    localad.a(String.class, new af.p(null));
    localad.a(UUID.class, new af.r(localad));
    return localad;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af
 * JD-Core Version:    0.7.0.1
 */