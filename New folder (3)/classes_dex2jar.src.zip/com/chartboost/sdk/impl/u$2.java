package com.chartboost.sdk.impl;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class u$2
  implements View.OnTouchListener
{
  u$2(u paramu) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return true;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.u.2
 * JD-Core Version:    0.7.0.1
 */