package com.chartboost.sdk.impl;

public abstract interface u$a
{
  public abstract void a();
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.u.a
 * JD-Core Version:    0.7.0.1
 */