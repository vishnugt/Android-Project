package com.chartboost.sdk.impl;

import android.view.View;
import android.view.View.OnClickListener;
import com.chartboost.sdk.c.c;

class b$a$2
  implements View.OnClickListener
{
  b$a$2(b.a parama) {}
  
  public void onClick(View paramView)
  {
    if (b.a.a(this.a).b != null) {
      b.a.a(this.a).b.a(null, null);
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.b.a.2
 * JD-Core Version:    0.7.0.1
 */