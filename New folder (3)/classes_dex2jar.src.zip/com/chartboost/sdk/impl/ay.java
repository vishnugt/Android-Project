package com.chartboost.sdk.impl;

import java.io.Serializable;

public class ay
  implements Serializable
{
  public boolean equals(Object paramObject)
  {
    return paramObject instanceof ay;
  }
  
  public int hashCode()
  {
    return 0;
  }
  
  public String toString()
  {
    return "MaxKey";
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.ay
 * JD-Core Version:    0.7.0.1
 */