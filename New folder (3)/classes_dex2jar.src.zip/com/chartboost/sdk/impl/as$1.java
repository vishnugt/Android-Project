package com.chartboost.sdk.impl;

class as$1
  extends bj<byte[]>
{
  as$1(int paramInt)
  {
    super(paramInt);
  }
  
  protected byte[] a()
  {
    return new byte[16384];
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.as.1
 * JD-Core Version:    0.7.0.1
 */