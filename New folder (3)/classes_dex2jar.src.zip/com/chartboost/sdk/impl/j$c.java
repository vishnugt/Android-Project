package com.chartboost.sdk.impl;

public abstract class j$c
  implements j.b
{
  public void a(k paramk, String paramString) {}
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.j.c
 * JD-Core Version:    0.7.0.1
 */