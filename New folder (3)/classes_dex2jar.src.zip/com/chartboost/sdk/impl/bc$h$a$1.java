package com.chartboost.sdk.impl;

import java.util.Map;

 enum bc$h$a$1
{
  bc$h$a$1()
  {
    super(str, i, null);
  }
  
  <K, V, M extends Map<K, V>> bc.h<K, V> a(bc<K, V, M> parambc)
  {
    parambc.getClass();
    return new bc.c(parambc);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.bc.h.a.1
 * JD-Core Version:    0.7.0.1
 */