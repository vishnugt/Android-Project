package com.chartboost.sdk.impl;

import java.util.HashMap;
import java.util.Map;

public class bh$a<K, V>
{
  private bc.h.a a = bc.h.a.a;
  private final Map<K, V> b = new HashMap();
  
  public bh<K, V> a()
  {
    return new bh.b(this.b, this.a);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.bh.a
 * JD-Core Version:    0.7.0.1
 */