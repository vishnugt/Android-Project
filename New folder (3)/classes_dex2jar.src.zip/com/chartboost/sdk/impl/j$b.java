package com.chartboost.sdk.impl;

import org.json.JSONObject;

public abstract interface j$b
{
  public abstract void a(k paramk, String paramString);
  
  public abstract void a(JSONObject paramJSONObject, k paramk);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.j.b
 * JD-Core Version:    0.7.0.1
 */