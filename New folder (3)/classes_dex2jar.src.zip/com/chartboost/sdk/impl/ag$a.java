package com.chartboost.sdk.impl;

public class ag$a
  extends RuntimeException
{
  final String a;
  
  ag$a(String paramString)
  {
    super(paramString);
    this.a = paramString;
  }
  
  public String toString()
  {
    return this.a;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.ag.a
 * JD-Core Version:    0.7.0.1
 */