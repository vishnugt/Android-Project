package com.chartboost.sdk.impl;

import org.json.JSONObject;

public abstract interface a$a
{
  public abstract void a(a parama);
  
  public abstract void a(a parama, String paramString, JSONObject paramJSONObject);
  
  public abstract void b(a parama);
  
  public abstract void c(a parama);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.a.a
 * JD-Core Version:    0.7.0.1
 */