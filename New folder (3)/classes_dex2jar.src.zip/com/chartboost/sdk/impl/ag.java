package com.chartboost.sdk.impl;

import java.util.regex.Pattern;

public class ag
{
  private static Pattern a = Pattern.compile("\\s+", 40);
  
  public static void a(int paramInt1, int paramInt2)
  {
    if (paramInt1 != paramInt2) {
      throw new ag.a(paramInt1 + " != " + paramInt2);
    }
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.ag
 * JD-Core Version:    0.7.0.1
 */