package com.chartboost.sdk.impl;

class af$b
  extends af.c
{
  af$b(ah paramah)
  {
    super(paramah);
  }
  
  public void a(Object paramObject, StringBuilder paramStringBuilder)
  {
    ax localax = (ax)paramObject;
    y localy = new y();
    localy.a("$code", localax.a());
    localy.a("$scope", localax.b());
    this.a.a(localy, paramStringBuilder);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.b
 * JD-Core Version:    0.7.0.1
 */