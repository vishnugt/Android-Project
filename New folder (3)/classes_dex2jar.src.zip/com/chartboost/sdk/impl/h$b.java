package com.chartboost.sdk.impl;

import org.json.JSONObject;

public abstract interface h$b
{
  public abstract int a();
  
  public abstract void a(JSONObject paramJSONObject, int paramInt);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.h.b
 * JD-Core Version:    0.7.0.1
 */