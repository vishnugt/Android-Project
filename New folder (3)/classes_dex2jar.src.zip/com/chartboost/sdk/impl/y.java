package com.chartboost.sdk.impl;

public class y
  extends ao
  implements aa
{
  public y() {}
  
  public y(String paramString, Object paramObject)
  {
    super(paramString, paramObject);
  }
  
  public String toString()
  {
    return ae.a(this);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.y
 * JD-Core Version:    0.7.0.1
 */