package com.chartboost.sdk.impl;

abstract class af$c
  extends ac
{
  protected final ah a;
  
  af$c(ah paramah)
  {
    this.a = paramah;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.impl.af.c
 * JD-Core Version:    0.7.0.1
 */