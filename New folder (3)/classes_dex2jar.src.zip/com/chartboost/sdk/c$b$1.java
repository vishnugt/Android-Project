package com.chartboost.sdk;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class c$b$1
  implements View.OnTouchListener
{
  c$b$1(c.b paramb) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return true;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.c.b.1
 * JD-Core Version:    0.7.0.1
 */