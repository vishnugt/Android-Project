package com.chartboost.sdk;

class Chartboost$2
  implements Runnable
{
  Chartboost$2(Chartboost paramChartboost) {}
  
  public void run()
  {
    Chartboost.d(this.a).d();
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Chartboost.2
 * JD-Core Version:    0.7.0.1
 */