package com.chartboost.sdk;

import com.chartboost.sdk.impl.j.b;
import com.chartboost.sdk.impl.k;
import com.chartboost.sdk.impl.n.a;
import org.json.JSONObject;

class a$1$1
  implements j.b
{
  a$1$1(a.1 param1, String paramString) {}
  
  public void a(k paramk, String paramString)
  {
    a.d(a.1.a(this.a)).a(false, this.b);
  }
  
  public void a(JSONObject paramJSONObject, k paramk)
  {
    a.a(a.1.a(this.a), paramJSONObject, this.b);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.a.1.1
 * JD-Core Version:    0.7.0.1
 */