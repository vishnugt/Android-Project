package com.chartboost.sdk;

import com.chartboost.sdk.impl.a.c;

class a$a
{
  private boolean a;
  private String b;
  private a.c c;
  
  public a$a(a.c paramc, String paramString, boolean paramBoolean)
  {
    this.c = paramc;
    this.b = paramString;
    a(paramBoolean);
  }
  
  public void a(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.a.a
 * JD-Core Version:    0.7.0.1
 */