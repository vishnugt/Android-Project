package com.chartboost.sdk;

class Chartboost$3
  implements Runnable
{
  Chartboost$3(Chartboost paramChartboost, b paramb) {}
  
  public void run()
  {
    this.b.a(true);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.Chartboost.3
 * JD-Core Version:    0.7.0.1
 */