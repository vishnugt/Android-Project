package com.chartboost.sdk;

import android.os.Handler;
import com.chartboost.sdk.impl.a;
import com.chartboost.sdk.impl.p.a;

class b$1
  implements p.a
{
  b$1(b paramb) {}
  
  public void a(a parama)
  {
    b.a(this.a).c.post(new b.b(this.a, parama, false));
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.b.1
 * JD-Core Version:    0.7.0.1
 */