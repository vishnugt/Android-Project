package com.chartboost.sdk;

class a$c
  implements Runnable
{
  private a$c(a parama) {}
  
  public void run()
  {
    if (a.e(this.a) != null)
    {
      a.c(this.a, a.e(this.a));
      return;
    }
    this.a.a(false);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.a.c
 * JD-Core Version:    0.7.0.1
 */