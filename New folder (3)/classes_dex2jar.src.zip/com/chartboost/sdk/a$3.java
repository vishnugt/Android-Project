package com.chartboost.sdk;

import com.chartboost.sdk.impl.a.c;
import com.chartboost.sdk.impl.j.b;
import com.chartboost.sdk.impl.k;
import org.json.JSONObject;

class a$3
  implements j.b
{
  a$3(a parama, boolean paramBoolean, String paramString) {}
  
  public void a(k paramk, String paramString)
  {
    a.a(this.a, a.c.b, this.c);
    b localb = a.b(this.a).a();
    if ((localb != null) && (localb.a())) {
      localb.a(true);
    }
  }
  
  public void a(JSONObject paramJSONObject, k paramk)
  {
    a.a(this.a, paramJSONObject, a.c.b, this.b, this.c, false);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.chartboost.sdk.a.3
 * JD-Core Version:    0.7.0.1
 */