package com.facebook;

abstract interface Request$KeyValueSerializer
{
  public abstract void writeString(String paramString1, String paramString2);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Request.KeyValueSerializer
 * JD-Core Version:    0.7.0.1
 */