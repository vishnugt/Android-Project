package com.facebook;

public enum AppEventsLogger$FlushBehavior
{
  static
  {
    FlushBehavior[] arrayOfFlushBehavior = new FlushBehavior[2];
    arrayOfFlushBehavior[0] = AUTO;
    arrayOfFlushBehavior[1] = EXPLICIT_ONLY;
    $VALUES = arrayOfFlushBehavior;
  }
  
  private AppEventsLogger$FlushBehavior() {}
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.AppEventsLogger.FlushBehavior
 * JD-Core Version:    0.7.0.1
 */