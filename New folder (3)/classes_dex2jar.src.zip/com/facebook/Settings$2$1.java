package com.facebook;

class Settings$2$1
  implements Runnable
{
  Settings$2$1(Settings.2 param2, Response paramResponse) {}
  
  public void run()
  {
    this.this$0.val$callback.onCompleted(this.val$response);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Settings.2.1
 * JD-Core Version:    0.7.0.1
 */