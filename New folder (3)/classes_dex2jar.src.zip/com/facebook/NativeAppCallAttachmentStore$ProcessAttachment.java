package com.facebook;

import java.io.File;

abstract interface NativeAppCallAttachmentStore$ProcessAttachment<T>
{
  public abstract void processAttachment(T paramT, File paramFile);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.NativeAppCallAttachmentStore.ProcessAttachment
 * JD-Core Version:    0.7.0.1
 */