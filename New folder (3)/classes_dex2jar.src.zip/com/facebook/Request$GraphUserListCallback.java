package com.facebook;

import com.facebook.model.GraphUser;
import java.util.List;

public abstract interface Request$GraphUserListCallback
{
  public abstract void onCompleted(List<GraphUser> paramList, Response paramResponse);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Request.GraphUserListCallback
 * JD-Core Version:    0.7.0.1
 */