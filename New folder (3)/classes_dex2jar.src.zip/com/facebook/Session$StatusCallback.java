package com.facebook;

public abstract interface Session$StatusCallback
{
  public abstract void call(Session paramSession, SessionState paramSessionState, Exception paramException);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Session.StatusCallback
 * JD-Core Version:    0.7.0.1
 */