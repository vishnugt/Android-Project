package com.facebook.internal;

class ImageDownloader$DownloaderContext
{
  boolean isCancelled;
  ImageRequest request;
  WorkQueue.WorkItem workItem;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.ImageDownloader.DownloaderContext
 * JD-Core Version:    0.7.0.1
 */