package com.facebook.internal;

public abstract interface ImageRequest$Callback
{
  public abstract void onCompleted(ImageResponse paramImageResponse);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.ImageRequest.Callback
 * JD-Core Version:    0.7.0.1
 */