package com.facebook.internal;

class FileLruCache$3
  implements Runnable
{
  FileLruCache$3(FileLruCache paramFileLruCache) {}
  
  public void run()
  {
    FileLruCache.access$200(this.this$0);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.FileLruCache.3
 * JD-Core Version:    0.7.0.1
 */