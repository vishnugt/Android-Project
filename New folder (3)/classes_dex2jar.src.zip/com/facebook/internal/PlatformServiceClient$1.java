package com.facebook.internal;

import android.os.Handler;
import android.os.Message;

class PlatformServiceClient$1
  extends Handler
{
  PlatformServiceClient$1(PlatformServiceClient paramPlatformServiceClient) {}
  
  public void handleMessage(Message paramMessage)
  {
    this.this$0.handleMessage(paramMessage);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.PlatformServiceClient.1
 * JD-Core Version:    0.7.0.1
 */