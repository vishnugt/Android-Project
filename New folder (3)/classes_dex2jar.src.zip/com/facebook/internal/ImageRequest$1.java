package com.facebook.internal;

class ImageRequest$1 {}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.ImageRequest.1
 * JD-Core Version:    0.7.0.1
 */