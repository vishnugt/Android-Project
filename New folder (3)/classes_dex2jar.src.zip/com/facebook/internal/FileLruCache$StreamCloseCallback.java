package com.facebook.internal;

abstract interface FileLruCache$StreamCloseCallback
{
  public abstract void onClose();
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.FileLruCache.StreamCloseCallback
 * JD-Core Version:    0.7.0.1
 */