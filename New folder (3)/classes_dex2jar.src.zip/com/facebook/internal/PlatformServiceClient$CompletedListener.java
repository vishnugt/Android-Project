package com.facebook.internal;

import android.os.Bundle;

public abstract interface PlatformServiceClient$CompletedListener
{
  public abstract void completed(Bundle paramBundle);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.internal.PlatformServiceClient.CompletedListener
 * JD-Core Version:    0.7.0.1
 */