package com.facebook;

class AppEventsLogger$FlushStatistics
{
  public int numEvents = 0;
  public AppEventsLogger.FlushResult result = AppEventsLogger.FlushResult.SUCCESS;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.AppEventsLogger.FlushStatistics
 * JD-Core Version:    0.7.0.1
 */