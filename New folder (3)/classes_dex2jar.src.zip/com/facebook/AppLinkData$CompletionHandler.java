package com.facebook;

public abstract interface AppLinkData$CompletionHandler
{
  public abstract void onDeferredAppLinkDataFetched(AppLinkData paramAppLinkData);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.AppLinkData.CompletionHandler
 * JD-Core Version:    0.7.0.1
 */