package com.facebook.widget;

import android.os.Bundle;
import com.facebook.FacebookException;

public abstract interface WebDialog$OnCompleteListener
{
  public abstract void onComplete(Bundle paramBundle, FacebookException paramFacebookException);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.widget.WebDialog.OnCompleteListener
 * JD-Core Version:    0.7.0.1
 */