package com.facebook.widget;

import android.content.Context;
import android.os.Bundle;
import com.facebook.Session;

public class WebDialog$Builder
  extends WebDialog.BuilderBase<Builder>
{
  public WebDialog$Builder(Context paramContext, Session paramSession, String paramString, Bundle paramBundle)
  {
    super(paramContext, paramSession, paramString, paramBundle);
  }
  
  public WebDialog$Builder(Context paramContext, String paramString1, String paramString2, Bundle paramBundle)
  {
    super(paramContext, paramString1, paramString2, paramBundle);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.widget.WebDialog.Builder
 * JD-Core Version:    0.7.0.1
 */