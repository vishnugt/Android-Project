package com.facebook;

public abstract interface RequestBatch$Callback
{
  public abstract void onBatchCompleted(RequestBatch paramRequestBatch);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.RequestBatch.Callback
 * JD-Core Version:    0.7.0.1
 */