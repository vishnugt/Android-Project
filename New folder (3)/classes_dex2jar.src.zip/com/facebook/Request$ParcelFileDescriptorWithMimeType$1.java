package com.facebook;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class Request$ParcelFileDescriptorWithMimeType$1
  implements Parcelable.Creator<Request.ParcelFileDescriptorWithMimeType>
{
  public final Request.ParcelFileDescriptorWithMimeType createFromParcel(Parcel paramParcel)
  {
    return new Request.ParcelFileDescriptorWithMimeType(paramParcel, null);
  }
  
  public final Request.ParcelFileDescriptorWithMimeType[] newArray(int paramInt)
  {
    return new Request.ParcelFileDescriptorWithMimeType[paramInt];
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Request.ParcelFileDescriptorWithMimeType.1
 * JD-Core Version:    0.7.0.1
 */