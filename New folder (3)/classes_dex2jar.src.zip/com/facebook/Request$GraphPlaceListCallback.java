package com.facebook;

import com.facebook.model.GraphPlace;
import java.util.List;

public abstract interface Request$GraphPlaceListCallback
{
  public abstract void onCompleted(List<GraphPlace> paramList, Response paramResponse);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Request.GraphPlaceListCallback
 * JD-Core Version:    0.7.0.1
 */