package com.facebook;

import java.io.File;
import java.util.UUID;

abstract interface NativeAppCallContentProvider$AttachmentDataSource
{
  public abstract File openAttachment(UUID paramUUID, String paramString);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.NativeAppCallContentProvider.AttachmentDataSource
 * JD-Core Version:    0.7.0.1
 */