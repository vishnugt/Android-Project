package com.facebook;

final class FacebookSdkVersion
{
  public static final String BUILD = "3.6.0";
  public static final String MIGRATION_BUNDLE = "fbsdk:20131203";
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.FacebookSdkVersion
 * JD-Core Version:    0.7.0.1
 */