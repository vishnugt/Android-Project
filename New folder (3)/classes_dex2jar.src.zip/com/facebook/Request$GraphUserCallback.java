package com.facebook;

import com.facebook.model.GraphUser;

public abstract interface Request$GraphUserCallback
{
  public abstract void onCompleted(GraphUser paramGraphUser, Response paramResponse);
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Request.GraphUserCallback
 * JD-Core Version:    0.7.0.1
 */