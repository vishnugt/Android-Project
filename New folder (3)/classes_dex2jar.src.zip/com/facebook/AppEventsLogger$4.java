package com.facebook;

final class AppEventsLogger$4
  implements Runnable
{
  AppEventsLogger$4(AppEventsLogger.FlushReason paramFlushReason) {}
  
  public final void run()
  {
    AppEventsLogger.access$100(this.val$reason);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.AppEventsLogger.4
 * JD-Core Version:    0.7.0.1
 */