package com.facebook;

public enum Response$PagingDirection
{
  static
  {
    PagingDirection[] arrayOfPagingDirection = new PagingDirection[2];
    arrayOfPagingDirection[0] = NEXT;
    arrayOfPagingDirection[1] = PREVIOUS;
    $VALUES = arrayOfPagingDirection;
  }
  
  private Response$PagingDirection() {}
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Response.PagingDirection
 * JD-Core Version:    0.7.0.1
 */