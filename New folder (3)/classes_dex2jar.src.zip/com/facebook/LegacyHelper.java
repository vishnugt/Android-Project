package com.facebook;

import android.os.Bundle;

public class LegacyHelper
{
  @Deprecated
  public static void extendTokenCompleted(Session paramSession, Bundle paramBundle)
  {
    paramSession.extendTokenCompleted(paramBundle);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.LegacyHelper
 * JD-Core Version:    0.7.0.1
 */