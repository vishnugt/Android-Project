package com.facebook;

public class FacebookGraphObjectException
  extends FacebookException
{
  static final long serialVersionUID = 1L;
  
  public FacebookGraphObjectException() {}
  
  public FacebookGraphObjectException(String paramString)
  {
    super(paramString);
  }
  
  public FacebookGraphObjectException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public FacebookGraphObjectException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.FacebookGraphObjectException
 * JD-Core Version:    0.7.0.1
 */