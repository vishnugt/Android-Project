package com.facebook.android;

public final class R$color
{
  public static final int com_facebook_blue = 2131099660;
  public static final int com_facebook_loginview_text_color = 2131099664;
  public static final int com_facebook_picker_search_bar_background = 2131099658;
  public static final int com_facebook_picker_search_bar_text = 2131099659;
  public static final int com_facebook_usersettingsfragment_connected_shadow_color = 2131099662;
  public static final int com_facebook_usersettingsfragment_connected_text_color = 2131099661;
  public static final int com_facebook_usersettingsfragment_not_connected_text_color = 2131099663;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.color
 * JD-Core Version:    0.7.0.1
 */