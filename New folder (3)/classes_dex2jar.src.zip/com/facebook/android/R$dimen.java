package com.facebook.android;

public final class R$dimen
{
  public static final int com_facebook_loginview_compound_drawable_padding = 2131296264;
  public static final int com_facebook_loginview_padding_bottom = 2131296263;
  public static final int com_facebook_loginview_padding_left = 2131296260;
  public static final int com_facebook_loginview_padding_right = 2131296261;
  public static final int com_facebook_loginview_padding_top = 2131296262;
  public static final int com_facebook_loginview_text_size = 2131296265;
  public static final int com_facebook_picker_divider_width = 2131296257;
  public static final int com_facebook_picker_place_image_size = 2131296256;
  public static final int com_facebook_profilepictureview_preset_size_large = 2131296268;
  public static final int com_facebook_profilepictureview_preset_size_normal = 2131296267;
  public static final int com_facebook_profilepictureview_preset_size_small = 2131296266;
  public static final int com_facebook_usersettingsfragment_profile_picture_height = 2131296259;
  public static final int com_facebook_usersettingsfragment_profile_picture_width = 2131296258;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.dimen
 * JD-Core Version:    0.7.0.1
 */