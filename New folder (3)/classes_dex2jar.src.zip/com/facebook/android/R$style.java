package com.facebook.android;

public final class R$style
{
  public static final int com_facebook_loginview_default_style = 2131034117;
  public static final int com_facebook_loginview_silver_style = 2131034118;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.style
 * JD-Core Version:    0.7.0.1
 */