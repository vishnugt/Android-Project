package com.facebook.android;

public final class R$attr
{
  public static final int confirm_logout = 2130771996;
  public static final int done_button_background = 2130771990;
  public static final int done_button_text = 2130771988;
  public static final int extra_fields = 2130771985;
  public static final int fetch_user_info = 2130771997;
  public static final int is_cropped = 2130772001;
  public static final int login_text = 2130771998;
  public static final int logout_text = 2130771999;
  public static final int multi_select = 2130771991;
  public static final int preset_size = 2130772000;
  public static final int radius_in_meters = 2130771992;
  public static final int results_limit = 2130771993;
  public static final int search_text = 2130771994;
  public static final int show_pictures = 2130771984;
  public static final int show_search_box = 2130771995;
  public static final int show_title_bar = 2130771986;
  public static final int title_bar_background = 2130771989;
  public static final int title_text = 2130771987;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.attr
 * JD-Core Version:    0.7.0.1
 */