package com.facebook.android;

public final class R$styleable
{
  public static final int[] com_facebook_friend_picker_fragment = { 2130771991 };
  public static final int com_facebook_friend_picker_fragment_multi_select = 0;
  public static final int[] com_facebook_login_view = { 2130771996, 2130771997, 2130771998, 2130771999 };
  public static final int com_facebook_login_view_confirm_logout = 0;
  public static final int com_facebook_login_view_fetch_user_info = 1;
  public static final int com_facebook_login_view_login_text = 2;
  public static final int com_facebook_login_view_logout_text = 3;
  public static final int[] com_facebook_picker_fragment = { 2130771984, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989, 2130771990 };
  public static final int com_facebook_picker_fragment_done_button_background = 6;
  public static final int com_facebook_picker_fragment_done_button_text = 4;
  public static final int com_facebook_picker_fragment_extra_fields = 1;
  public static final int com_facebook_picker_fragment_show_pictures = 0;
  public static final int com_facebook_picker_fragment_show_title_bar = 2;
  public static final int com_facebook_picker_fragment_title_bar_background = 5;
  public static final int com_facebook_picker_fragment_title_text = 3;
  public static final int[] com_facebook_place_picker_fragment = { 2130771992, 2130771993, 2130771994, 2130771995 };
  public static final int com_facebook_place_picker_fragment_radius_in_meters = 0;
  public static final int com_facebook_place_picker_fragment_results_limit = 1;
  public static final int com_facebook_place_picker_fragment_search_text = 2;
  public static final int com_facebook_place_picker_fragment_show_search_box = 3;
  public static final int[] com_facebook_profile_picture_view = { 2130772000, 2130772001 };
  public static final int com_facebook_profile_picture_view_is_cropped = 1;
  public static final int com_facebook_profile_picture_view_preset_size;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.styleable
 * JD-Core Version:    0.7.0.1
 */