package com.facebook.android;

public final class R$layout
{
  public static final int com_facebook_friendpickerfragment = 2130903041;
  public static final int com_facebook_login_activity_layout = 2130903042;
  public static final int com_facebook_picker_activity_circle_row = 2130903043;
  public static final int com_facebook_picker_checkbox = 2130903044;
  public static final int com_facebook_picker_image = 2130903045;
  public static final int com_facebook_picker_list_row = 2130903046;
  public static final int com_facebook_picker_list_section_header = 2130903047;
  public static final int com_facebook_picker_search_box = 2130903048;
  public static final int com_facebook_picker_title_bar = 2130903049;
  public static final int com_facebook_picker_title_bar_stub = 2130903050;
  public static final int com_facebook_placepickerfragment = 2130903051;
  public static final int com_facebook_placepickerfragment_list_row = 2130903052;
  public static final int com_facebook_search_bar_layout = 2130903053;
  public static final int com_facebook_usersettingsfragment = 2130903054;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.layout
 * JD-Core Version:    0.7.0.1
 */