package com.facebook.android;

public final class R$string
{
  public static final int com_facebook_choose_friends = 2130968640;
  public static final int com_facebook_dialogloginactivity_ok_button = 2130968625;
  public static final int com_facebook_internet_permission_error_message = 2130968644;
  public static final int com_facebook_internet_permission_error_title = 2130968643;
  public static final int com_facebook_loading = 2130968642;
  public static final int com_facebook_loginview_cancel_action = 2130968631;
  public static final int com_facebook_loginview_log_in_button = 2130968627;
  public static final int com_facebook_loginview_log_out_action = 2130968630;
  public static final int com_facebook_loginview_log_out_button = 2130968626;
  public static final int com_facebook_loginview_logged_in_as = 2130968628;
  public static final int com_facebook_loginview_logged_in_using_facebook = 2130968629;
  public static final int com_facebook_logo_content_description = 2130968632;
  public static final int com_facebook_nearby = 2130968641;
  public static final int com_facebook_picker_done_button_text = 2130968639;
  public static final int com_facebook_placepicker_subtitle_catetory_only_format = 2130968637;
  public static final int com_facebook_placepicker_subtitle_format = 2130968636;
  public static final int com_facebook_placepicker_subtitle_were_here_only_format = 2130968638;
  public static final int com_facebook_requesterror_password_changed = 2130968647;
  public static final int com_facebook_requesterror_permissions = 2130968649;
  public static final int com_facebook_requesterror_reconnect = 2130968648;
  public static final int com_facebook_requesterror_relogin = 2130968646;
  public static final int com_facebook_requesterror_web_login = 2130968645;
  public static final int com_facebook_usersettingsfragment_log_in_button = 2130968633;
  public static final int com_facebook_usersettingsfragment_logged_in = 2130968634;
  public static final int com_facebook_usersettingsfragment_not_logged_in = 2130968635;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.string
 * JD-Core Version:    0.7.0.1
 */