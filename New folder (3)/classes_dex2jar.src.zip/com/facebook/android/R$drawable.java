package com.facebook.android;

public final class R$drawable
{
  public static final int com_facebook_button_blue = 2130837504;
  public static final int com_facebook_button_blue_focused = 2130837505;
  public static final int com_facebook_button_blue_normal = 2130837506;
  public static final int com_facebook_button_blue_pressed = 2130837507;
  public static final int com_facebook_button_check = 2130837508;
  public static final int com_facebook_button_check_off = 2130837509;
  public static final int com_facebook_button_check_on = 2130837510;
  public static final int com_facebook_button_grey_focused = 2130837511;
  public static final int com_facebook_button_grey_normal = 2130837512;
  public static final int com_facebook_button_grey_pressed = 2130837513;
  public static final int com_facebook_close = 2130837514;
  public static final int com_facebook_inverse_icon = 2130837515;
  public static final int com_facebook_list_divider = 2130837516;
  public static final int com_facebook_list_section_header_background = 2130837517;
  public static final int com_facebook_loginbutton_silver = 2130837518;
  public static final int com_facebook_logo = 2130837519;
  public static final int com_facebook_picker_default_separator_color = 2130837566;
  public static final int com_facebook_picker_item_background = 2130837520;
  public static final int com_facebook_picker_list_focused = 2130837521;
  public static final int com_facebook_picker_list_longpressed = 2130837522;
  public static final int com_facebook_picker_list_pressed = 2130837523;
  public static final int com_facebook_picker_list_selector = 2130837524;
  public static final int com_facebook_picker_list_selector_background_transition = 2130837525;
  public static final int com_facebook_picker_list_selector_disabled = 2130837526;
  public static final int com_facebook_picker_magnifier = 2130837527;
  public static final int com_facebook_picker_top_button = 2130837528;
  public static final int com_facebook_place_default_icon = 2130837529;
  public static final int com_facebook_profile_default_icon = 2130837530;
  public static final int com_facebook_profile_picture_blank_portrait = 2130837531;
  public static final int com_facebook_profile_picture_blank_square = 2130837532;
  public static final int com_facebook_top_background = 2130837533;
  public static final int com_facebook_top_button = 2130837534;
  public static final int com_facebook_usersettingsfragment_background_gradient = 2130837535;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.drawable
 * JD-Core Version:    0.7.0.1
 */