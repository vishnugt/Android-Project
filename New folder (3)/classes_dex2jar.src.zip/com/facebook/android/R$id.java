package com.facebook.android;

public final class R$id
{
  public static final int com_facebook_login_activity_progress_bar = 2131165193;
  public static final int com_facebook_picker_activity_circle = 2131165192;
  public static final int com_facebook_picker_checkbox = 2131165195;
  public static final int com_facebook_picker_checkbox_stub = 2131165199;
  public static final int com_facebook_picker_divider = 2131165203;
  public static final int com_facebook_picker_done_button = 2131165202;
  public static final int com_facebook_picker_image = 2131165196;
  public static final int com_facebook_picker_list_section_header = 2131165200;
  public static final int com_facebook_picker_list_view = 2131165191;
  public static final int com_facebook_picker_profile_pic_stub = 2131165197;
  public static final int com_facebook_picker_row_activity_circle = 2131165194;
  public static final int com_facebook_picker_search_text = 2131165208;
  public static final int com_facebook_picker_title = 2131165198;
  public static final int com_facebook_picker_title_bar = 2131165205;
  public static final int com_facebook_picker_title_bar_stub = 2131165204;
  public static final int com_facebook_picker_top_bar = 2131165201;
  public static final int com_facebook_search_bar_view = 2131165207;
  public static final int com_facebook_usersettingsfragment_login_button = 2131165211;
  public static final int com_facebook_usersettingsfragment_logo_image = 2131165209;
  public static final int com_facebook_usersettingsfragment_profile_name = 2131165210;
  public static final int large = 2131165190;
  public static final int normal = 2131165185;
  public static final int picker_subtitle = 2131165206;
  public static final int small = 2131165189;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.R.id
 * JD-Core Version:    0.7.0.1
 */