package com.facebook.android;

import android.os.Bundle;
import com.facebook.FacebookException;
import com.facebook.widget.WebDialog.OnCompleteListener;

class FbDialog$1
  implements WebDialog.OnCompleteListener
{
  FbDialog$1(FbDialog paramFbDialog) {}
  
  public void onComplete(Bundle paramBundle, FacebookException paramFacebookException)
  {
    FbDialog.access$000(this.this$0, paramBundle, paramFacebookException);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.android.FbDialog.1
 * JD-Core Version:    0.7.0.1
 */