package com.facebook;

import java.util.HashSet;

final class Session$1
  extends HashSet<String>
{
  Session$1()
  {
    add("ads_management");
    add("create_event");
    add("rsvp_event");
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Session.1
 * JD-Core Version:    0.7.0.1
 */