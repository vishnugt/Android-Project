package com.facebook;

class Session$3$1
  implements Runnable
{
  Session$3$1(Session.3 param3, Session.StatusCallback paramStatusCallback) {}
  
  public void run()
  {
    this.val$callback.call(this.this$1.this$0, this.this$1.val$newState, this.this$1.val$exception);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.Session.3.1
 * JD-Core Version:    0.7.0.1
 */