package com.facebook;

class LoginActivity$1
  implements AuthorizationClient.OnCompletedListener
{
  LoginActivity$1(LoginActivity paramLoginActivity) {}
  
  public void onCompleted(AuthorizationClient.Result paramResult)
  {
    LoginActivity.access$000(this.this$0, paramResult);
  }
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.facebook.LoginActivity.1
 * JD-Core Version:    0.7.0.1
 */