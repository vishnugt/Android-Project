package com.android.vending.a.a;

public final class b
{
  public static final int kilobytes_per_second = 2130968596;
  public static final int notification_download_complete = 2130968576;
  public static final int notification_download_failed = 2130968577;
  public static final int state_completed = 2130968583;
  public static final int state_connecting = 2130968581;
  public static final int state_downloading = 2130968582;
  public static final int state_failed = 2130968595;
  public static final int state_failed_cancelled = 2130968594;
  public static final int state_failed_fetching_url = 2130968592;
  public static final int state_failed_sdcard_full = 2130968593;
  public static final int state_failed_unlicensed = 2130968591;
  public static final int state_fetching_url = 2130968580;
  public static final int state_idle = 2130968579;
  public static final int state_paused_by_request = 2130968586;
  public static final int state_paused_network_setup_failure = 2130968585;
  public static final int state_paused_network_unavailable = 2130968584;
  public static final int state_paused_roaming = 2130968589;
  public static final int state_paused_sdcard_unavailable = 2130968590;
  public static final int state_paused_wifi_disabled = 2130968588;
  public static final int state_paused_wifi_unavailable = 2130968587;
  public static final int state_unknown = 2130968578;
  public static final int time_remaining = 2130968597;
  public static final int time_remaining_notification = 2130968598;
}


/* Location:           C:\Users\vishnu\Desktop\New folder (3)\classes_dex2jar.jar
 * Qualified Name:     com.android.vending.a.a.b
 * JD-Core Version:    0.7.0.1
 */