This is my second file for App Dev Task 3.  This is for Windows App Dev and the previous one was for Android.


Name: Vishnu G
Task: Task 3
Profile Name: App Development
Branch: Instumentation and Control Engineering
Roll No:110113096

My User name in the induction process is vishnugt

My repo link Github:- https://github.com/vishnugt/Spider-Task-3/tree/master/BingMapWindowsStoreApp

